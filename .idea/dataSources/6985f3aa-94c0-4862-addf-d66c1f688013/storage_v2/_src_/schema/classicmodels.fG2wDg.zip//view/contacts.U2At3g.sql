create definer = root@localhost view contacts as
select `classicmodels`.`employees`.`lastName`  AS `lastName`,
       `classicmodels`.`employees`.`firstName` AS `firstName`,
       `classicmodels`.`employees`.`extension` AS `phone`
from `classicmodels`.`employees`
union
select `classicmodels`.`customers`.`contactFirstName` AS `contactFirstName`,
       `classicmodels`.`customers`.`contactLastName`  AS `contactLastName`,
       `classicmodels`.`customers`.`phone`            AS `phone`
from `classicmodels`.`customers`;

